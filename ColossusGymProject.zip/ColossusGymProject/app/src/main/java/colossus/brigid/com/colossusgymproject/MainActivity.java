package colossus.brigid.com.colossusgymproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button logout;
    private Button gym_location;
    private Button gym_instructor;
    private Button workout_sessions;
    private Button past_workouts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        logout = (Button)findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        gym_location = (Button) findViewById(R.id.gym_location);
        gym_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(intent);
            }
        });

        gym_instructor = (Button) findViewById(R.id.gym_instructor);
        gym_instructor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, InstructorActivity.class);
                startActivity(intent);
            }
        });

        workout_sessions = (Button) findViewById(R.id.workout_sessions);
        workout_sessions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,WorkoutSessionsActivity .class);
                startActivity(intent);
            }
        });

        past_workouts = (Button) findViewById(R.id.past_workouts);
        past_workouts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,PastWorkoutsActivity .class);
                startActivity(intent);
            }
        });


    }

    public void UserProfile(View view) {
        Intent intent = new Intent(MainActivity.this, UserProfileActivity.class);
        startActivity(intent);
    }


}
