package colossus.brigid.com.colossusgymproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ListAdapter extends BaseAdapter {

    PastWorkoutsActivity main;

    ListAdapter(PastWorkoutsActivity main)
    {
        this.main = main;
    }

    @Override
    public int getCount() {
        return  main.past.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    static class ViewHolderItem {
        TextView name;
        TextView code;
        TextView sets;
        TextView reps;
        TextView tempo;
        TextView date;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        ViewHolderItem holder = new ViewHolderItem();
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) main.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.cell, null);

            holder.name = (TextView) convertView.findViewById(R.id.name);
            holder.code = (TextView) convertView.findViewById(R.id.code);
            holder.sets = (TextView) convertView.findViewById(R.id.sets);
            holder.reps = (TextView) convertView.findViewById(R.id.reps);
            holder.tempo = (TextView) convertView.findViewById(R.id.tempo);
            holder.date = (TextView) convertView.findViewById(R.id.date);



            convertView.setTag(holder);
        }
        else
        {
            holder = (ViewHolderItem) convertView.getTag();
        }


        holder.name.setText(this.main.past.get(position).name);
        holder.code.setText(this.main.past.get(position).code);
        holder.sets.setText(this.main.past.get(position).sets);
        holder.reps.setText(this.main.past.get(position).reps);
        holder.tempo.setText(this.main.past.get(position).tempo);
        holder.date.setText(this.main.past.get(position).date);



        return convertView;
    }

}
