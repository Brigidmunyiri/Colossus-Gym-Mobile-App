package colossus.brigid.com.colossusgymproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import java.util.ArrayList;

public class InstructorActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    //vars
    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();
    private ArrayList<String>  mAges = new ArrayList<>()  ;
    private ArrayList<String>  mGenders = new ArrayList<>()  ;
    private ArrayList<String>  mContacts = new ArrayList<>()  ;
    private ArrayList<String>  mEmails = new ArrayList<>()  ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructor);
        Log.d(TAG, "onCreate: started.");

        initImageBitmaps();
    }

    private void initImageBitmaps(){
        Log.d(TAG, "initImageBitmaps: preparing bitmaps.");

        mImageUrls.add("https://brigidlearning.000webhostapp.com/gympics/image.jpg");
        mNames.add("Moufasa");
        mAges.add("24");
        mGenders.add("Male");
        mContacts.add("072534824");
        mEmails.add("mouf@fejgr.com");

        mImageUrls.add("https://brigidlearning.000webhostapp.com/gympics/image1.jpg");
        mNames.add("Kagawa");
        mAges.add("29");
        mGenders.add("Male");
        mContacts.add("072734824");
        mEmails.add("kag@fejgr.com");

        mImageUrls.add("https://brigidlearning.000webhostapp.com/gympics/image2.jpg");
        mNames.add("Lima");
        mAges.add("22");
        mGenders.add("Female");
        mContacts.add("072834824");
        mEmails.add("lim@fejgr.com");

        mImageUrls.add("https://brigidlearning.000webhostapp.com/gympics/image3.jpg");
        mNames.add("Vin");
        mAges.add("25");
        mGenders.add("Male");
        mContacts.add("072934824");
        mEmails.add("vin@fejgr.com");


        mImageUrls.add("https://brigidlearning.000webhostapp.com/gympics/image4.jpg");
        mNames.add("Sabina");
        mAges.add("30");
        mGenders.add("Female");
        mContacts.add("072234824");
        mEmails.add("ryutu@fejgr.com");

        initRecyclerView();
    }

    private void initRecyclerView(){
        Log.d(TAG, "initRecyclerView: init recyclerview.");
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, mImageUrls, mNames, mAges, mGenders, mContacts, mEmails);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}