package colossus.brigid.com.colossusgymproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import java.util.ArrayList;

public class InstructorActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    //vars
    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();
    private ArrayList<String>  mAges = new ArrayList<>()  ;
    private ArrayList<String>  mGenders = new ArrayList<>()  ;
    private ArrayList<String>  mContacts = new ArrayList<>()  ;
    private ArrayList<String>  mEmails = new ArrayList<>()  ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructor);
        Log.d(TAG, "onCreate: started.");

        initImageBitmaps();
    }

    private void initImageBitmaps(){
        Log.d(TAG, "initImageBitmaps: preparing bitmaps.");

        mImageUrls.add("https://i.imgur.com/ZcLLrkY.jpg");
        mNames.add("Moufasa");
        mAges.add("25");
        mGenders.add("Male");
        mContacts.add("072634824");
        mEmails.add("ryutu@fejgr.com");

        mImageUrls.add("https://i.redd.it/tpsnoz5bzo501.jpg");
        mNames.add("Trondheim");
        mAges.add("25");
        mGenders.add("Male");
        mContacts.add("072634824");
        mEmails.add("ryutu@fejgr.com");

        mImageUrls.add("https://i.redd.it/qn7f9oqu7o501.jpg");
        mNames.add("Portugal");
        mAges.add("25");
        mGenders.add("Male");
        mContacts.add("072634824");
        mEmails.add("ryutu@fejgr.com");

        mImageUrls.add("https://i.redd.it/j6myfqglup501.jpg");
        mNames.add("Rocky Mountain National Park");
        mAges.add("25");
        mGenders.add("Male");
        mContacts.add("072634824");
        mEmails.add("ryutu@fejgr.com");


        mImageUrls.add("https://i.redd.it/0h2gm1ix6p501.jpg");
        mNames.add("Mahahual");
        mAges.add("25");
        mGenders.add("Male");
        mContacts.add("072634824");
        mEmails.add("ryutu@fejgr.com");

        initRecyclerView();
    }

    private void initRecyclerView(){
        Log.d(TAG, "initRecyclerView: init recyclerview.");
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, mImageUrls, mNames, mAges, mGenders, mContacts, mEmails);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}