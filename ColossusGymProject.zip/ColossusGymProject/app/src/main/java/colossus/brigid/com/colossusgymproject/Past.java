package colossus.brigid.com.colossusgymproject;

public class Past {

    String date;
    String name;
    String code;
    String sets;
    String reps;
    String tempo;

}

