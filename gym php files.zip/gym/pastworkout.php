<?php

	 include 'config.inc.php';
	 
	  if(isset($_GET['location']) && isset($_GET['type'])&& isset($_GET['sets'])&& isset($_GET['reps'])&& isset($_GET['tempo']))
     {
	 
		// Innitialize Variable
		  $result='';
		  
		  
          $sql = 'SELECT * FROM sessions94121 WHERE  location = :location, type = :type, sets = :sets, reps: reps, tempo: tempo)';
          $stmt = $conn->prepare($sql);
		  $stmt->bindParam(':location', $location, PDO::PARAM_STR);
          $stmt->bindParam(':type', $type, PDO::PARAM_STR);
		  $stmt->bindParam(':sets', $sets, PDO::PARAM_STR);
          $stmt->bindParam(':reps', $reps, PDO::PARAM_STR);
		  $stmt->bindParam(':tempo', $tempo, PDO::PARAM_STR);

          $stmt->execute();
		  if($stmt->rowCount())
          {
			  <tr>
		  <td><?php echo $result['location'];?></td>
		  <td><?php echo $result['type'];?></td>
		  <td><?php echo $result['sets'];?></td>
		  <td><?php echo $result['reps'];?></td>
		  <td><?php echo $result['tempo'];?></td>
		  </tr>
          $result="true";
		  }  
	 elseif(!$stmt->rowCount())
          {
			  	$result="false";
          }
		  
		  // send result back to android
   		  echo $result;
  	}
	
?>